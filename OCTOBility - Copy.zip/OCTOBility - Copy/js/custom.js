// Get Current Year
function getCurrentYear() {
    var d = new Date();
    var year = d.getFullYear();
    document.querySelector("#displayDateYear").innerText = year;
}
getCurrentYear()

//client section owl carousel
$(".owl-carousel").owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    navText: [
        '<i class="fa fa-long-arrow-left" aria-hidden="true"></i>',
        '<i class="fa fa-long-arrow-right" aria-hidden="true"></i>'
    ],
    autoplay: true,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        768: {
            items: 2
        },
        1000: {
            items: 2
        }
    }
});

/** google_map js **/

function myMap() {
    var mapProp = {
        center: new google.maps.LatLng(40.712775, -74.005973),
        zoom: 18,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}


function loadDecode() {
			  var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				  var data = JSON.parse(this.responseText);
				  document.getElementById("myimage").src = data.results[0].picture.large
				}
			  };
			  xhttp.open("GET", "https://randomuser.me/api", true);
			  xhttp.send();
}

$("#button2").click( async function() {
    
    const assignment = await getAssignment();
   // $("#imagedisp").attr("src", 'data:image/gif;base64,' + $("#frame").text());
    const assignment2 = await getAssignment3();

});




// =========== text to voice


$("#button3").click( async function() {	

//const assignment = await getAssignmentIndo();

	var selectedFunction = document.getElementById('lang').value;
            switch (selectedFunction) {
                case 'idn':
					//const assignment = await getAssignmentIndo();
                    getAssignmentIndo();
                    break;
                case 'eng':
					textInput = $("#text").val();
					//const assignment = await getAssignment(textInput);
                    getAssignmentEng(textInput);
                    break;
                default:
                    console.log('Fungsi tidak ditemukan.');
    }
   
});



async function getAssignmentIndo() {
    fetch('https://demoml.cakra.ai/tts/synthesize_audio',{
   	method: "POST",
    mode: "cors",
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
    body: JSON.stringify({text: $("#text").val() })    
    
    })
  // Retrieve its body as ReadableStream
  .then(response => response.body)
  .then(rs => {
    const reader = rs.getReader();

    return new ReadableStream({
      async start(controller) {
        while (true) {
          const { done, value } = await reader.read();

          // When no more data needs to be consumed, break the reading
          if (done) {
            break;
          }

          // Enqueue the next data chunk into our target stream
          controller.enqueue(value);
        }

        // Close the stream
        controller.close();
        reader.releaseLock();
      }
    })
  })
  // Create a new response out of the stream
  .then(rs => {
      
      return new Response(rs);
  
  })
  // Create an object URL for the response
  .then(response => {
      value = response.json();
      
      return value;
  
  })
  .then(text => {
      //console.dir(text.audio);
      var snd = new Audio('data:audio/wav;base64,' + text.audio);
      audioplayer.src = 'data:audio/wav;base64,' + text.audio;
      $("#button").prop("disabled", false);
  })
  .catch(console.error);

}


async function getAssignmentEng(textinput) {
    const data = new URLSearchParams();
    data.append('text', textinput);

    fetch('https://5jege89gij.execute-api.ap-southeast-1.amazonaws.com/default/texttospeech?text='+textinput,{
   	method: "POST",
    mode: "cors"
   
    
    
    })
   // Retrieve its body as ReadableStream
   .then(response => {
   
       const value = response.body;
       console.dir(value);
       return value;
   })
   .then(rs => {
     const reader = rs.getReader();

     return new ReadableStream({
       async start(controller) {
         while (true) {
           const { done, value } = await reader.read();

           // When no more data needs to be consumed, break the reading
           if (done) {
             break;
           }

           // Enqueue the next data chunk into our target stream
           controller.enqueue(value);
         }

         // Close the stream
         controller.close();
         reader.releaseLock();
       }
     })
   })
   // Create a new response out of the stream
   .then(rs => {
       
       return new Response(rs);
   
   })
   // Create an object URL for the response
   .then(response => {
       const value = response.json();
       
       return value;
   
   })
   .then(text => {
       vl = text.audio;
       console.dir(vl);
       audioplayer.src = 'data:audio/mp3;base64,' + vl;
       $("#button").prop("disabled", false);
      
   }) 
   .catch(console.error);

}

//=============================== untuk carousel

$("#button3").click(  function() {
    inputval = $("#text").val();
	langval = $("#lang").val();
	
    inputText = inputval.split(" ");
    lgth = inputText.length; 
    count = 0;
	linx = '';
	
	switch (langval) {
		case 'idn':
			linx = 'https://5jege89gij.execute-api.ap-southeast-1.amazonaws.com/default/converttexttoimage';
			break;
		case 'eng':
			linx = 'https://5jege89gij.execute-api.ap-southeast-1.amazonaws.com/default/converttexttoimage_en';
			break;
		default:
			console.log('Fungsi tidak ditemukan.');
    }
    
    
    htmlline ='';
    for (x=0; x< lgth; x++){
        if (x==0)
          htmlline = htmlline + "<div class=\"carousel-item active\"> <img class=\"d-block w-100\" id=\"lbl"     +inputText[x]+  "\" alt=\"  " +inputText[x]+  " \"> </div>";
        else
          htmlline = htmlline + "<div class=\"carousel-item\"> <img class=\"d-block w-100\" id=\"lbl"     +inputText[x]+  "\" alt=\"  " +inputText[x]+  " \"> </div>"
        
    
    }
    $(".carousel-inner").html(htmlline);
    
    while (count < lgth) {
   
    const assignment =  getCarousel(inputText[count], linx);
  
    count ++;
   }

});


function getCarousel(inputText, linx) {

        //fetch('https://5jege89gij.execute-api.ap-southeast-1.amazonaws.com/default/converttexttoimage?text='+inputText,{
		fetch(linx+'?text='+inputText,{
       	method: "GET",
        mode: "cors",
        
        
        })
      // Retrieve its body as ReadableStream
      .then(response => response.body)
      .then(rs => {
        const reader = rs.getReader();
    
        return new ReadableStream({
          async start(controller) {
            while (true) {
              const { done, value } = await reader.read();
    
              // When no more data needs to be consumed, break the reading
              if (done) {
                break;
              }
    
              // Enqueue the next data chunk into our target stream
              controller.enqueue(value);
            }
    
            // Close the stream
            controller.close();
            reader.releaseLock();
          }
        })
      })
      // Create a new response out of the stream
      .then(rs => {
          
          return new Response(rs);
      
      })
      // Create an object URL for the response
      .then(response => {
          value = response.text();
          
          return value;
      
      })
      .then(text => {
          inp = "lbl"+inputText;
          $("#"+inp+"").attr('src','data:image/gif;base64,' + text);
          
          
    
      })
      .catch(console.error);
    
    
}   



//=============================== voice recording

$("#buttonVoice").click( async function(e) {
    e.preventDefault();
    
	langval = $("#lang").val();
	linx = '';
	
	switch (langval) {
		case 'idn':
			linx = 'https://5jege89gij.execute-api.ap-southeast-1.amazonaws.com/default/converttexttoimage';
			break;
		case 'eng':
			linx = 'https://5jege89gij.execute-api.ap-southeast-1.amazonaws.com/default/converttexttoimage_en';
			break;
		default:
			console.log('Fungsi tidak ditemukan.');
    }
	
	const assignment = await getAssignmentVoiceRec(linx);
});

const b64toBlob = (b64Data, contentType='', sliceSize=512) => {
  const byteCharacters = atob(b64Data);
  const byteArrays = [];

  for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    const slice = byteCharacters.slice(offset, offset + sliceSize);

    const byteNumbers = new Array(slice.length);
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }
    
  const blob = new Blob(byteArrays, {type: contentType});
  return blob;
}


async function getAssignmentVoiceRec(linx) {
   const formData = new FormData();
   //const fileInput = document.querySelector("#fileinput");
   const fileInput =  $("#audioplayer").find("source").attr("src");
   const val = fileInput.split(";",3);
   const value = val[2].split(",",2);
   console.dir(value);
   const blob = b64toBlob(value[1], "audio/wav");

      
   
   console.dir(blob);
   
  // value = $("#audioplayer").find("source").attr("src");
  
     //fl = $("#file").prop('files');
     //file = file[0];
     
   file = new File([blob], 'test.webm',{ type: 'audio/webm' });
   console.dir(file);
   formData.append( 'file', file);
   a.href = URL.createObjectURL(blob);
   a.download = name;
   
   
  

    fetch('https://demoml.cakra.ai/stt/process_full?language=id',{
   	method: "POST",
    mode: "cors",

    body: formData
    
    })
  // Retrieve its body as ReadableStream
  .then(response => {
  
      const value = response.body;
      console.dir(value);
      return value;
  })
  .then(rs => {
    const reader = rs.getReader();

    return new ReadableStream({
      async start(controller) {
        while (true) {
          const { done, value } = await reader.read();

          // When no more data needs to be consumed, break the reading
          if (done) {
            break;
          }

          // Enqueue the next data chunk into our target stream
          controller.enqueue(value);
        }

        // Close the stream
        controller.close();
        reader.releaseLock();
      }
    })
  })
  // Create a new response out of the stream
  .then(rs => {
      
      return new Response(rs);
  
  })
  // Create an object URL for the response
  .then(response => {
      const value = response.json();
      
      return value;
  
  })
  .then(text => {
      vl = text.data;
     
	  // untuk subtitle
      $("#subtitle").text(vl);
      console.dir(vl);
	  
	  
	  //untuk carousel
	  inputText = vl.split(" ");
      lgth = inputText.length; 
      count = 0;
    
    
      htmlline ='';
      for (x=0; x< lgth; x++){
          if (x==0)
            htmlline = htmlline + "<div class=\"carousel-item active\"> <img class=\"d-block w-100\" id=\"lbl"     +inputText[x]+  "\" alt=\"  " +inputText[x]+  " \"> </div>";
          else
            htmlline = htmlline + "<div class=\"carousel-item\"> <img class=\"d-block w-100\" id=\"lbl"     +inputText[x]+  "\" alt=\"  " +inputText[x]+  " \"> </div>"
        
    
      }
      $(".carousel-inner").html(htmlline);
    
      while (count < lgth) {
   
      const assignment =  getCarousel(inputText[count],linx);
  
      count ++;
     }
	 //carousel selesai
  }) 
  .catch(console.error);

}

